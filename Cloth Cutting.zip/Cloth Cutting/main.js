// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Constants
    const CLOTH_SIZE = 30;
    const CLOTH_RESOLUTION = 40;
    const CLOTH_HEIGHT = 20;
    const GRAVITY = -9.82;
    const DAMPING = 0.03;
    const DRAG = 1 - 0.01;
    const ITERATIONS = 5;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x111122);
    scene.fog = new THREE.FogExp2(0x111122, 0.0025);

    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 10, 50);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    document.body.appendChild(renderer.domElement);

    // Controls
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.screenSpacePanning = false;
    controls.minDistance = 10;
    controls.maxDistance = 100;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x666666);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1);
    dirLight.position.set(10, 20, 10);
    dirLight.castShadow = true;
    dirLight.shadow.camera.near = 0.1;
    dirLight.shadow.camera.far = 500;
    dirLight.shadow.camera.left = -100;
    dirLight.shadow.camera.right = 100;
    dirLight.shadow.camera.top = 100;
    dirLight.shadow.camera.bottom = -100;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    // Physics world
    const world = new CANNON.World({
        gravity: new CANNON.Vec3(0, GRAVITY, 0)
    });
    world.solver.iterations = ITERATIONS;
    world.solver.tolerance = 0.001;

    // Create cloth
    function createCloth() {
        // Build positions and indices for a (CLOTH_RESOLUTION+1)x(CLOTH_RESOLUTION+1) grid
        const numParticles = CLOTH_RESOLUTION + 1;
        const positions = new Float32Array(numParticles * numParticles * 3);
        const indices = [];
        // Create grid positions
        let ptr = 0;
        for (let y = 0; y < numParticles; y++) {
            for (let x = 0; x < numParticles; x++) {
                const uvx = x / CLOTH_RESOLUTION;
                const uvy = y / CLOTH_RESOLUTION;
                const px = (uvx - 0.5) * CLOTH_SIZE;
                const pz = (uvy - 0.5) * CLOTH_SIZE;
                const py = 20;
                positions[ptr++] = px;
                positions[ptr++] = py;
                positions[ptr++] = pz;
            }
        }
        // Build index buffer for rendering as a triangle mesh
        for (let y = 0; y < CLOTH_RESOLUTION; y++) {
            for (let x = 0; x < CLOTH_RESOLUTION; x++) {
                const a = y * numParticles + x;
                const b = y * numParticles + (x + 1);
                const c = (y + 1) * numParticles + x;
                const d = (y + 1) * numParticles + (x + 1);
                indices.push(a, b, d);
                indices.push(a, d, c);
            }
        }
        const clothGeometry = new THREE.BufferGeometry();
        clothGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        clothGeometry.setIndex(indices);
        clothGeometry.computeVertexNormals();

        // Create particles
        const particles = [];
        const constraints = [];
        const particleMass = 1;
        const particleRadius = 0.1;
        const distance = CLOTH_SIZE / CLOTH_RESOLUTION;
        
        function addConstraintAndStore(p1, p2, dist) {
            const constraint = new CANNON.DistanceConstraint(p1, p2, dist);
            world.addConstraint(constraint);
            constraints.push({ constraint, p1, p2 });
            return constraint;
        }
        
        for (let y = 0; y < numParticles; y++) {
            particles[y] = [];
            for (let x = 0; x < numParticles; x++) {
                const idx = y * numParticles + x;
                const px = positions[idx * 3];
                const py = positions[idx * 3 + 1];
                const pz = positions[idx * 3 + 2];
                const isFixed = (y === 0 && (x % 5 === 0));
                const particle = new CANNON.Body({
                    mass: isFixed ? 0 : particleMass,
                    position: new CANNON.Vec3(px, py, pz),
                    shape: new CANNON.Sphere(particleRadius),
                    linearDamping: DAMPING,
                    material: new CANNON.Material('cloth')
                });
                particle.radius = particleRadius * 0.5;
                particles[y][x] = particle;
                world.addBody(particle);
            }
        }
        
        // Create distance constraints
        for (let y = 0; y < numParticles; y++) {
            for (let x = 0; x < numParticles; x++) {
                if (x < CLOTH_RESOLUTION) {
                    addConstraintAndStore(particles[y][x], particles[y][x + 1], distance);
                }
                if (y < CLOTH_RESOLUTION) {
                    addConstraintAndStore(particles[y][x], particles[y + 1][x], distance);
                }
                if (x < CLOTH_RESOLUTION && y < CLOTH_RESOLUTION) {
                    addConstraintAndStore(particles[y][x], particles[y + 1][x + 1], distance * Math.SQRT2);
                    addConstraintAndStore(particles[y + 1][x], particles[y][x + 1], distance * Math.SQRT2);
                }
            }
        }

        const material = new THREE.MeshPhysicalMaterial({
            color: 0x204080, // rich blue
            side: THREE.DoubleSide,
            flatShading: false,
            roughness: 0.7,
            metalness: 0.0,
            sheen: 1.0,
            sheenColor: 0xffffff,
            sheenRoughness: 0.5,
            transparent: true,
            opacity: 0.93,
            transmission: 0.04 // a bit of light-through
        });
        const clothMesh = new THREE.Mesh(clothGeometry, material);
        clothMesh.castShadow = true;
        clothMesh.receiveShadow = true;
        scene.add(clothMesh);
        return {
            mesh: clothMesh,
            particles: particles,
            geometry: clothGeometry,
            constraints: constraints
        };
    }

    // Helper function to create constraints
    function createConstraint(p1, p2, distance) {
        const constraint = new CANNON.DistanceConstraint(p1, p2, distance);
        world.addConstraint(constraint);
        return constraint;
    }

    let cloth = createCloth();

    // Update cloth mesh
    function updateClothMesh() {
        const { particles, geometry } = cloth;
        const position = geometry.attributes.position.array;
        const numParticles = CLOTH_RESOLUTION + 1;
        let idx = 0;
        for (let y = 0; y < numParticles; y++) {
            for (let x = 0; x < numParticles; x++) {
                const particle = particles[y][x];
                if (particle) {
                    position[idx * 3] = particle.position.x;
                    position[idx * 3 + 1] = particle.position.y;
                    position[idx * 3 + 2] = particle.position.z;
                }
                idx++;
            }
        }
        geometry.attributes.position.needsUpdate = true;
        geometry.computeVertexNormals();
    }

// Cut the cloth
function cutCloth(startPoint, endPoint) {
    const { constraints, particles, mesh, geometry } = cloth;
    const cutThickness = 0.5; // How thick the cut should be
    const numParticles = CLOTH_RESOLUTION + 1;
    
    console.log('cutCloth called with', constraints.length, 'constraints');
    
    // Helper: check if two line segments intersect in 2D (x,z plane)
    function lineSegmentsIntersect(p1, p2, p3, p4) {
        // Convert to 2D (x,z coordinates)
        const a1 = p2.z - p1.z;
        const b1 = p1.x - p2.x;
        const c1 = a1 * p1.x + b1 * p1.z;

        const a2 = p4.z - p3.z;
        const b2 = p3.x - p4.x;
        const c2 = a2 * p3.x + b2 * p3.z;

        const determinant = a1 * b2 - a2 * b1;

        if (determinant === 0) {
            return false; // Lines are parallel
        }

        const x = (b2 * c1 - b1 * c2) / determinant;
        const z = (a1 * c2 - a2 * c1) / determinant;

        // Check if the intersection point is within both line segments
        const isOnSegment1 = (Math.min(p1.x, p2.x) <= x) && (x <= Math.max(p1.x, p2.x)) &&
                            (Math.min(p1.z, p2.z) <= z) && (z <= Math.max(p1.z, p2.z));
                            
        const isOnSegment2 = (Math.min(p3.x, p4.x) <= x) && (x <= Math.max(p3.x, p4.x)) &&
                            (Math.min(p3.z, p4.z) <= z) && (z <= Math.max(p3.z, p4.z));

        return isOnSegment1 && isOnSegment2;
    }

    // Find constraints that cross the cut line
    const toRemove = [];
    
    // Create a bounding box around the cut line to limit the search space
    const minX = Math.min(startPoint.x, endPoint.x) - cutThickness;
    const maxX = Math.max(startPoint.x, endPoint.x) + cutThickness;
    const minZ = Math.min(startPoint.z, endPoint.z) - cutThickness;
    const maxZ = Math.max(startPoint.z, endPoint.z) + cutThickness;

    // Check each constraint to see if it crosses the cut line
    for (let i = 0; i < constraints.length; i++) {
        const { constraint, p1, p2 } = constraints[i];
        if (!p1 || !p2 || !p1.position || !p2.position) continue;
        
        const p1Pos = new THREE.Vector3(p1.position.x, p1.position.y, p1.position.z);
        const p2Pos = new THREE.Vector3(p2.position.x, p2.position.y, p2.position.z);
        
        // Quick bounding box check to skip constraints that are too far from the cut
        if (p1Pos.x < minX && p2Pos.x < minX) continue;
        if (p1Pos.x > maxX && p2Pos.x > maxX) continue;
        if (p1Pos.z < minZ && p2Pos.z < minZ) continue;
        if (p1Pos.z > maxZ && p2Pos.z > maxZ) continue;
        
        // Check if the constraint line segment intersects with the cut line
        if (lineSegmentsIntersect(
            { x: startPoint.x, z: startPoint.z },
            { x: endPoint.x, z: endPoint.z },
            { x: p1Pos.x, z: p1Pos.z },
            { x: p2Pos.x, z: p2Pos.z }
        )) {
            toRemove.push(constraint);
        }
    }
    
    console.log(`Found ${toRemove.length} constraints to remove`);
    
    // Remove the constraints
    for (let remove of toRemove) {
        world.removeConstraint(remove);
        const idx = constraints.findIndex(ent => ent.constraint === remove);
        if (idx !== -1) constraints.splice(idx, 1);
    }
    
    console.log(`Cut complete: Removed ${toRemove.length} constraints, ${constraints.length} remaining`);
}
    // Mouse interaction
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let isCutting = false;
    let freezeCloth = false; // <--- added
    let cutStartPoint = new THREE.Vector3();
    let cutEndPoint = new THREE.Vector3();
    let cutLine = null;

    function onMouseDown(event) {
        mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObject(cloth.mesh);
        
        if (intersects.length > 0) {
            isCutting = true;
            freezeCloth = true; // freeze!
            cutStartPoint = intersects[0].point;
            cutEndPoint = cutStartPoint.clone();
            updateCutLine();
        }
    }

    function onMouseMove(event) {
        if (!isCutting) return;
        
        mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
        
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObject(cloth.mesh);
        
        if (intersects.length > 0) {
            cutEndPoint = intersects[0].point;
            updateCutLine();
        }
    }

    function onMouseUp() {
        if (!isCutting) return;
        isCutting = false;
        freezeCloth = false; // resume!
        
        // Always try to cut, even for small movements
        const dist = cutStartPoint.distanceTo(cutEndPoint);
        console.log('Mouse up, cut distance:', dist);
        if (dist > 0.1) {
            console.log('Calling cutCloth...');
            cutCloth(cutStartPoint, cutEndPoint);
        }
        
        if (cutLine) {
            scene.remove(cutLine);
            cutLine = null;
        }
    }

    function updateCutLine() {
        if (cutLine) {
            scene.remove(cutLine);
        }
        
        const geometry = new THREE.BufferGeometry().setFromPoints([cutStartPoint, cutEndPoint]);
        const material = new THREE.LineBasicMaterial({ color: 0xff0000, linewidth: 3 });
        cutLine = new THREE.Line(geometry, material);
        scene.add(cutLine);
    }

    // Add event listeners
    renderer.domElement.addEventListener('mousedown', onMouseDown);
    renderer.domElement.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('mouseup', onMouseUp);
    renderer.domElement.addEventListener('mouseleave', onMouseUp);

    // Handle window resize
    function onWindowResize() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }
    window.addEventListener('resize', onWindowResize);

    // Animation loop
    function animate() {
        requestAnimationFrame(animate);
        
        if (!freezeCloth) {
            // Step the physics world
            world.step(1/60);
            
            // Update the cloth mesh
            updateClothMesh();
        }
        
        // Update controls
        controls.update();
        
        // Render the scene
        renderer.render(scene, camera);
    }

    // Start the animation loop
    animate();
});